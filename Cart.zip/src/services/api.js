export default {
  hotWordsUrl:"http://vueshop.glbuys.com/api/home/public/hotwords?token=1ec949a15fb709370f",
  login:"http://vueshop.glbuys.com/api/home/user/pwdlogin?token=1ec949a15fb709370f",
  reg:"http://vueshop.glbuys.com/api/home/user/reg?token=1ec949a15fb709370f",
  opcode:'http://vueshop.glbuys.com/api/vcode/chkcode?token=1ec949a15fb709370f',
  hashCode:"http://vueshop.glbuys.com/api/home/user/checkvcode?token=1ec949a15fb709370f",
}