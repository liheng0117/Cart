import home from "@/reducer/home";
import login from "@/reducer/login";
import reg from "@/reducer/reg";
export { 
  home,
  login,
  reg,
};
