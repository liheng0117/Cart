import React, { Component } from "react";
import "./style.less";

export default class Home extends Component {
  render() {
    return <div className="home">home</div>;
  }
}
